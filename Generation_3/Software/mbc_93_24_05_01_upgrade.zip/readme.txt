Firmware zum Upgrade des Moduls mbc-93

HW: 24.05.01

FW: 1.00 - Basisversion
FW: 1.01 - Anpassung des CS-Kenners als Booster

