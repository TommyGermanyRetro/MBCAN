Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-81

HW: 24.01.06

FW: 1.00 - Erste Version
