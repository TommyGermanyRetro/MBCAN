Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-87

HW: 19.11.17

FW: 1.00 - Basisversion
FW: 1.05 - Optimierung der Kommunikation zur CS3
FW: 2.00 - Kommunikationsfunktionen verbessert
FW: 2.11 - CAN-Empfindlichkeit angepasst
FW: 2.16 - DS 18B20 adaptiert
FW: 3.00 - Umstellung auf Funktionsdecoder-Methode
