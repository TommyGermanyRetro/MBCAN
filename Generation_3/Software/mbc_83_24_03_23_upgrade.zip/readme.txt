Firmware zum Up-/Downgrade des Moduls mbc-83

HW: 24.03.23

FW: 1.00 - Erste Version
FW: 1.01 - Rueckmeldung angepasst
