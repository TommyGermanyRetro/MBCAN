Firmware zum Up-/Downgrade des Moduls mbc-83

HW: 18.02.10

FW: 1.05 - Optimierung der Kommunikation zur CS3
FW: 2.00 - Kommunikationsfunktionen angepasst
FW: 2.10 - Rückmeldezyklus optimiert
FW: 2.11 - CAN-Empfindlichkeit angepasst
FW: 2.16 - DS 18B20 adaptiert
FW: 2.17 - Dimmerfunktion angepasst