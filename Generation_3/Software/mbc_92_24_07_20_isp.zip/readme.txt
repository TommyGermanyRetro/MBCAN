Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-92

HW: 24.07.20

FW: 1.00 - Basisversion


