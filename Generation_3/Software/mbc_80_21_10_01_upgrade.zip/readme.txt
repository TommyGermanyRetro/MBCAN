Firmware zum Up-/Downgrade des Moduls mbc-80

HW: 21.10.01

FW: 1.00 - Basisversion
FW: 1.10 - Optimierung der Stellungsrückmeldung mbc-83, mbc-84 und mbc-91
FW: 1.11 - Zentralenerkennung zur Vermeidung eines Not-Stopp bei Nutzung der MS2 und Gleisbox
FW: 1.15 - Bug bei Kenner beseitigt
FW: 1.16 - DS-Typerkennung für die Temperaturerfassung
FW: 1.17 - Rocrail-Funktionalität ergänzt

