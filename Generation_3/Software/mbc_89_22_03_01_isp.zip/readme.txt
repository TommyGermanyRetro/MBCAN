Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-89

HW: 22.03.01

FW: 1.00 - Erste Version
FW: 1.01 - I2C-Kommunikation angepasst
FW: 1.02 - PullUp am Eingang des CU-Sensors deaktiviert
FW: 1.03 - Variable Frequenzen fuer I2C-Bus eingefuehrt
FW: 1.04 - Programmierbare I2C-Bus-Frequenzen eingefuehrt
FW: 1.05 - Rückmeldung Strom aus auf gewählten Ausgang angepasst
FW: 2.16 - DS 18B20 adaptiert	


