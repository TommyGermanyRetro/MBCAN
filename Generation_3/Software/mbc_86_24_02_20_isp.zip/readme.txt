Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-86

HW: 24.02.20

FW: 1.00 - Erste Version
