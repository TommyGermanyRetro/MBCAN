Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-81

HW: 18.02.12

FW: 1.05 - Optimierung der Kommunikation zur CS3
FW: 2.00 - BUS 0 Funktion für den mbc-80/L88 ergänzt
FW: 2.11 - CAN-Empfindlichkeit angepasst
FW: 2.16 - DS 18B20 adaptiert