Firmware zum Upgrade des Moduls mbc-91

HW: 24.04.01

FW: 1.00 - Basisversion
FW: 1.01 - Rückmeldung angepasst

