Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-90

HW: 23.11.25

FW: 1.00 - Basisversion

