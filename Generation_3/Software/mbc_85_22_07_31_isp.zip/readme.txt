Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-85

HW: 22.07.31

FW: 1.00 - Erste Version
