Firmware zum Up-/Downgrade des Moduls mbc-89

HW: 22.03.01

FW: 1.00 - Erste Version
    1.01 - I2C-Kommunikation angepasst
    1.02 - PullUp am Eingang des CU-Sensors deaktiviert
    1.03 - Variable Frequenzen fuer I2C-Bus eingefuehrt
    1.04 - Programmierbare I2C-Bus-Frequenzen eingefuehrt	
    1.05 - Rückmeldung Strom aus auf gewählten Ausgang angepasst
    2.16 - DS 18B20 adaptiert


