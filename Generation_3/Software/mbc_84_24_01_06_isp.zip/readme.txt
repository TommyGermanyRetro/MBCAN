Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-84

HW: 24.01.06

FW: 1.00 - Erste Version
