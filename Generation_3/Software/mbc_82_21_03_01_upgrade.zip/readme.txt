Firmware zum Up-/Downgrade des Moduls mbc-82

HW: 21.03.01

FW: 1.00 - Basisversion
FW: 2.00 - Kommunikationsfunktionen angepasst
FW: 2.11 - CAN-Empfindlichkeit angepasst
FW: 2.16 - DS 18B20 adaptiert