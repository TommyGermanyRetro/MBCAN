Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-84

HW: 18.02.03

FW: 1.05 - Optimierung der Kommunikation zur CS3
FW: 1.06 - Optimierung der Stellungsrueckmeldung auf dem MBCAN-Bus und Start der Servos
FW: 2.00 - Kommunikationsfunktionen angepasst
FW: 2.10 - Rückmeldezyklus auf Anforderung vom LinkS88 ausgelagert
FW: 2.11 - CAN-Empfindlichkeit angepasst
FW: 2.16 - DS 18B20 adaptiert
