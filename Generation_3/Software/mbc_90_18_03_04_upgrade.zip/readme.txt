Firmware zum Upgrade des Moduls mbc-90

HW: 18.03.04

FW: 1.05 - Kommunikation mit der CS3 verbessert
FW: 1.06 - Bus 1 bis 3 Funktionalität aktiviert
FW: 2.00 - Bus 0 Funktionalität aktiviert
FW: 2.11 - CAN-Empfindlichkeit angepasst
FW: 2.16 - DS 18B20 adaptiert
