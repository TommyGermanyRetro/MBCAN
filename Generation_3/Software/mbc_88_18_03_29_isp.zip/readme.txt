Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-88

HW: 18.03.29

FW: 1.05 - Kommunikation mit der CS3 verbessert
FW: 1.06 - Bus 1 bis 3 des LinkS88 aktiviert
FW: 2.00 - Kommunikationsfunktionen verbessert
FW: 2.11 - CAN-Empfindlichkeit angepasst
FW: 2.16 - DS 18B20 adaptiert
