Firmware inkl. Bootloader zur initialen Programmierung des Moduls mbc-80

HW: 18.02.03

RS232+BT

FW: 1.05 - Optimierung des Datenmodells und Vorbereitung auf Erweiterungen fuer die CS3
FW: 1.06 - L88-SW-Version aenderbar
FW: 2.00 - Allgemeiner Bugfix, UDP-Funktion zur CSx ergänzt
FW: 2.01 - Protokollverbesserungen im UDP-Betrieb
FW: 2.10 - Rückmeldeprozess mbc-83, mbc-84 und mbc-91 optimiert
FW: 2.11 - Zentralenerkennung zur Vermeidung eines Not-Stopp bei Nutzung der MS2 und Gleisbox
FW: 2.15 - Bug beim Kenner beseitigt
FW: 2.16 - DS-Typ-Erkennung Temperaturberechnung

ESP

FW: 3.00 - Basisversion
FW: 3.10 - Rückmeldeprozess mbc-83, mbc-84 und mbc-91 optimiert
FW: 3.11 - Zentralenerkennung zur Vermeidung eines Not-Stopp bei Nutzung der MS2 und Gleisbox
FW: 3.15 - Bug beim Kenner beseitigt
FW: 3.16 - DS-Typ-Erkennung Temperaturberechnung
FW: 3.17 - Rocrail-Funktionalität ergänzt

